//
//  anilframework.h
//  anilframework
//
//  Created by Anil on 31/07/19.
//  Copyright © 2019 Anil. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for anilframework.
FOUNDATION_EXPORT double anilframeworkVersionNumber;

//! Project version string for anilframework.
FOUNDATION_EXPORT const unsigned char anilframeworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <anilframework/PublicHeader.h>


